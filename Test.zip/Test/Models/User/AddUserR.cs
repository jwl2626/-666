﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.User
{
    public class AddUserR
    {
        public int code { get; set; }
        public string msg { get; set; }
    }
}
