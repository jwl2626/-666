﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.User
{
    public class AddUseP
    {
        public string phone { get; set; }
        public string password { get; set; }
        public string nickName { get; set; }
        public int state { get; set; }
    }
}
