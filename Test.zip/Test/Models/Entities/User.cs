﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Entities
{
    public class User
    {
        public int Id { get; set; }
        public string Phone { get; set; }
        public string Password { get; set; }
        public string NickName { get; set; }
        public int State { get; set; }

        
    }
}
