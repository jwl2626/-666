﻿namespace Bo.Interfaces
{
    public class AddUserP
    {
        internal string phone;
        internal string password;
        internal string nickName;
        internal int state;
        internal int code;
        internal string msg;
    }
}