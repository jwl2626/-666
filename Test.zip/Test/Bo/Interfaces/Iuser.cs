﻿using Models.User;

namespace Bo.Interfaces
{
    public interface Iuser
    { 
        AddUserR AddUser(AddUserP model);
    }

}