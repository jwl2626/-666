﻿using System.Linq;
using Models.Entities;
using Models.User;

namespace Bo.Interfaces
{
    public class UserBo : Iuser
    {
        public static Db db=new Db();
        public AddUserR AddUser(AddUserP model)
        {
            var d = new AddUserR();
            
                User user = new User();
                user.Phone = model.phone;
                user.Password = model.password;
                user.NickName = model.nickName;
                user.State = model.state;
                db.User.Add(user);
                int i = db.SaveChanges();
                if (i > 0)
                {
                    d.code = 1;
                    d.msg = "数据插入成功";
                }
                else
                {
                    d.code = 0;
                    d.msg = "数据插入失败";
                }

                return d;
            
        }

        
        
    }
}
