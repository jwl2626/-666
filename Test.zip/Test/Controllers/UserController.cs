﻿using Bo.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Models.User;

namespace Test.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
      
        private readonly Iuser _user;

        public UserController(Iuser user)
        {
            this._user = user;
        }

       [HttpPost]
        public IActionResult Add([FromBody]AddUserP model)
        {
            var r = _user.AddUser(model);
            return Ok("r");
        }
    }
}
